public class name {
    public static void main(String[] arg) {
        System.out.println("Patrick Finnigan");
    }
}