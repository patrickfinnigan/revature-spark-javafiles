package packagetwo;

import packageone.ProtectedClass;

public class ProtectedSubClass extends ProtectedClass {

}