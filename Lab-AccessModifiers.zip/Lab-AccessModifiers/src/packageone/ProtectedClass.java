package packageone;

public class ProtectedClass {
    protected long id = 1L;
    protected void printID() { System.out.println(this.id); }
}