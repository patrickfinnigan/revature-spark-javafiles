public class Person{
    public int age;
}