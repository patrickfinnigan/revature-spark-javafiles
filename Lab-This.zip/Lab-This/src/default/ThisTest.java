public class ThisTest {

    public static void main(String[] args) {
        A classA = new A();

        // classA.setId(2);

        System.out.println(classA.getId());
    }
}