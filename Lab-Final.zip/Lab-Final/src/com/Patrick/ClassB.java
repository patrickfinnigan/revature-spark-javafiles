package com.Patrick;

public final class ClassB extends ClassA {
   
    public final void someMethod(int x){
       System.out.println("Some method.");
    }
}