package com.Patrick;

public class ClassA {
    public String greeting = "Hello";

    public final void someMethod(){
        System.out.println("Some method.");
    }
}