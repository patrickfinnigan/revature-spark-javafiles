module Inheritance {
}