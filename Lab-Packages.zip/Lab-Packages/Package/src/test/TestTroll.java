package test;

import model.Troll;

public class TestTroll {
    public static void main(String[] args){
        Troll troll = new Troll();
     }
}